"""Configuration management for AB Code Reviewer."""
