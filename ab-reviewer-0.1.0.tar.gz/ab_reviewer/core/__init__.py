"""Core functionality for AB Code Reviewer."""
