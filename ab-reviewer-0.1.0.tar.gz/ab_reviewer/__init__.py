"""AB Code Reviewer - Automated code review workflow with AI integration."""

__version__ = "0.1.0"
__author__ = "AB Code Reviewer"
__email__ = "ab@example.com"
