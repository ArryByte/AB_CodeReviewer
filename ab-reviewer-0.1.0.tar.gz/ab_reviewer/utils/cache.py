"""Caching utilities for AB Code Reviewer."""

import hashlib
import json
import time
from pathlib import Path
from typing import Any, Dict, Optional


class ToolCache:
    """Simple file-based cache for tool results."""
    
    def __init__(self, cache_dir: Path, ttl_seconds: int = 3600):
        """
        Initialize cache.
        
        Args:
            cache_dir: Directory to store cache files
            ttl_seconds: Time-to-live for cache entries in seconds
        """
        self.cache_dir = cache_dir
        self.ttl_seconds = ttl_seconds
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_cache_key(self, tool_name: str, args: list, project_path: Path) -> str:
        """Generate cache key for tool execution."""
        key_data = {
            "tool": tool_name,
            "args": args,
            "project": str(project_path),
            "mtime": self._get_project_mtime(project_path)
        }
        key_string = json.dumps(key_data, sort_keys=True)
        return hashlib.md5(key_string.encode()).hexdigest()
    
    def _get_project_mtime(self, project_path: Path) -> float:
        """Get maximum modification time of Python files in project."""
        max_mtime = 0
        for py_file in project_path.rglob("*.py"):
            try:
                mtime = py_file.stat().st_mtime
                max_mtime = max(max_mtime, mtime)
            except OSError:
                continue
        return max_mtime
    
    def get(self, tool_name: str, args: list, project_path: Path) -> Optional[Dict[str, Any]]:
        """
        Get cached result for tool execution.
        
        Args:
            tool_name: Name of the tool
            args: Tool arguments
            project_path: Project path
            
        Returns:
            Cached result or None if not found/expired
        """
        cache_key = self._get_cache_key(tool_name, args, project_path)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if not cache_file.exists():
            return None
        
        try:
            with open(cache_file, 'r') as f:
                data = json.load(f)
            
            # Check if cache is expired
            if time.time() - data.get("timestamp", 0) > self.ttl_seconds:
                cache_file.unlink()
                return None
            
            return data.get("result")
        
        except (json.JSONDecodeError, OSError):
            cache_file.unlink(missing_ok=True)
            return None
    
    def set(self, tool_name: str, args: list, project_path: Path, result: Dict[str, Any]) -> None:
        """
        Cache tool execution result.
        
        Args:
            tool_name: Name of the tool
            args: Tool arguments
            project_path: Project path
            result: Result to cache
        """
        cache_key = self._get_cache_key(tool_name, args, project_path)
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            data = {
                "timestamp": time.time(),
                "result": result
            }
            
            with open(cache_file, 'w') as f:
                json.dump(data, f)
        
        except OSError:
            # Ignore cache write errors
            pass
    
    def clear(self) -> None:
        """Clear all cache entries."""
        for cache_file in self.cache_dir.glob("*.json"):
            cache_file.unlink(missing_ok=True)
