"""Input validation utilities for AB Code Reviewer."""

import os
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional

from .exceptions import ValidationError, ConfigurationError


def validate_project_path(project_path: Path) -> None:
    """
    Validate project path.
    
    Args:
        project_path: Path to validate
        
    Raises:
        ValidationError: If path is invalid
    """
    if not project_path.exists():
        raise ValidationError(f"Project path does not exist: {project_path}")
    
    if not project_path.is_dir():
        raise ValidationError(f"Project path is not a directory: {project_path}")
    
    if not os.access(project_path, os.R_OK):
        raise ValidationError(f"No read access to project path: {project_path}")


def validate_python_version(min_version: tuple = (3, 8)) -> None:
    """
    Validate Python version.
    
    Args:
        min_version: Minimum required Python version
        
    Raises:
        ValidationError: If Python version is too old
    """
    if sys.version_info < min_version:
        raise ValidationError(
            f"Python {min_version[0]}.{min_version[1]}+ required, "
            f"found {sys.version_info.major}.{sys.version_info.minor}"
        )


def validate_configuration(config: Dict[str, Any]) -> None:
    """
    Validate configuration structure.
    
    Args:
        config: Configuration dictionary to validate
        
    Raises:
        ConfigurationError: If configuration is invalid
    """
    required_sections = ["project", "tools", "ai"]
    
    for section in required_sections:
        if section not in config:
            raise ConfigurationError(f"Missing required configuration section: {section}")
    
    # Validate project section
    project = config["project"]
    if "type" not in project:
        raise ConfigurationError("Missing 'type' in project configuration")
    
    if project["type"] not in ["python"]:
        raise ConfigurationError(f"Unsupported project type: {project['type']}")
    
    # Validate tools section
    tools = config["tools"]
    required_tools = ["formatter", "linter", "security", "tests"]
    
    for tool in required_tools:
        if tool not in tools:
            raise ConfigurationError(f"Missing required tool configuration: {tool}")
        
        tool_config = tools[tool]
        if not isinstance(tool_config, dict):
            raise ConfigurationError(f"Tool configuration must be a dictionary: {tool}")
        
        if "enabled" in tool_config and not isinstance(tool_config["enabled"], bool):
            raise ConfigurationError(f"Tool 'enabled' must be boolean: {tool}")


def validate_tool_arguments(tool_name: str, args: List[str]) -> None:
    """
    Validate tool arguments.
    
    Args:
        tool_name: Name of the tool
        args: Arguments to validate
        
    Raises:
        ValidationError: If arguments are invalid
    """
    if not isinstance(args, list):
        raise ValidationError(f"Tool arguments must be a list: {tool_name}")
    
    for arg in args:
        if not isinstance(arg, str):
            raise ValidationError(f"Tool argument must be a string: {tool_name}")


def validate_file_path(file_path: Path, must_exist: bool = True) -> None:
    """
    Validate file path.
    
    Args:
        file_path: Path to validate
        must_exist: Whether file must exist
        
    Raises:
        ValidationError: If path is invalid
    """
    if must_exist and not file_path.exists():
        raise ValidationError(f"File does not exist: {file_path}")
    
    if file_path.exists() and not file_path.is_file():
        raise ValidationError(f"Path is not a file: {file_path}")


def validate_directory_path(dir_path: Path, must_exist: bool = True) -> None:
    """
    Validate directory path.
    
    Args:
        dir_path: Path to validate
        must_exist: Whether directory must exist
        
    Raises:
        ValidationError: If path is invalid
    """
    if must_exist and not dir_path.exists():
        raise ValidationError(f"Directory does not exist: {dir_path}")
    
    if dir_path.exists() and not dir_path.is_dir():
        raise ValidationError(f"Path is not a directory: {dir_path}")
